param(
  [string]$OutputRoot = "$PSScriptRoot\deployment\out",
  [string]$PackageName = ("ssw-ops-platform-iis-" + (Get-Date -Format "yyyyMMdd-HHmmss"))
)

$ErrorActionPreference = "Stop"

function Ensure-Directory {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
    New-Item -Path $Path -ItemType Directory -Force | Out-Null
  }
}

$projectRoot = $PSScriptRoot
$stageRoot = Join-Path $OutputRoot $PackageName
$zipPath = Join-Path $OutputRoot ($PackageName + ".zip")

Ensure-Directory -Path $OutputRoot

if (Test-Path -LiteralPath $stageRoot) {
  $suffix = [Guid]::NewGuid().ToString("N").Substring(0, 6)
  $stageRoot = Join-Path $OutputRoot "$PackageName-$suffix"
  $zipPath = Join-Path $OutputRoot ("$PackageName-$suffix.zip")
}

Ensure-Directory -Path $stageRoot

$requiredFiles = @(
  "index.html",
  "README.md"
)

$requiredDirs = @(
  "app",
  "styles",
  "public"
)

foreach ($file in $requiredFiles) {
  $source = Join-Path $projectRoot $file
  if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
    throw "Required file not found: $source"
  }
  Copy-Item -LiteralPath $source -Destination (Join-Path $stageRoot $file) -Force
}

foreach ($dir in $requiredDirs) {
  $source = Join-Path $projectRoot $dir
  if (-not (Test-Path -LiteralPath $source -PathType Container)) {
    throw "Required folder not found: $source"
  }
  Copy-Item -LiteralPath $source -Destination (Join-Path $stageRoot $dir) -Recurse -Force
}

$webConfigSource = Join-Path $projectRoot "deployment\iis\web.config"
if (-not (Test-Path -LiteralPath $webConfigSource -PathType Leaf)) {
  throw "IIS web.config template not found: $webConfigSource"
}
Copy-Item -LiteralPath $webConfigSource -Destination (Join-Path $stageRoot "web.config") -Force

$readme = @"
CDC SSW Ops Platform - IIS Package

Contents
- index.html
- app/
- styles/
- public/
- web.config

Quick publish (IIS)
1. Create a site or virtual app in IIS.
2. Point physical path to this extracted folder.
3. Ensure Default Document is enabled (index.html).
4. Browse the site URL.

Important
- This version stores edits in browser localStorage (per user / per browser).
- External map/data endpoints require outbound internet allow-list:
  - services.arcgis.com
  - services5.arcgis.com
  - api.unhcr.org
"@

Set-Content -LiteralPath (Join-Path $stageRoot "START-HERE-IIS.txt") -Value $readme -Encoding UTF8

if (Test-Path -LiteralPath $zipPath -PathType Leaf) {
  Remove-Item -LiteralPath $zipPath -Force
}

$archiveSource = Get-ChildItem -LiteralPath $stageRoot -Force
if (-not $archiveSource) {
  throw "No files found in staging folder: $stageRoot"
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($stageRoot, $zipPath, [System.IO.Compression.CompressionLevel]::Optimal, $false)

Write-Host "IIS package ready:" -ForegroundColor Green
Write-Host "  Folder: $stageRoot"
Write-Host "  Zip:    $zipPath"
