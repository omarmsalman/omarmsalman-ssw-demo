param(
  [int]$Port = 4173,
  [string]$Root = $PSScriptRoot
)

function Get-ContentType {
  param([string]$Path)
  switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
    ".html" { "text/html; charset=utf-8" }
    ".css"  { "text/css; charset=utf-8" }
    ".js"   { "text/javascript; charset=utf-8" }
    ".json" { "application/json; charset=utf-8" }
    ".svg"  { "image/svg+xml" }
    ".png"  { "image/png" }
    ".jpg"  { "image/jpeg" }
    ".jpeg" { "image/jpeg" }
    ".webp" { "image/webp" }
    default { "application/octet-stream" }
  }
}

function Send-Response {
  param(
    [System.Net.Sockets.NetworkStream]$Stream,
    [int]$StatusCode,
    [string]$StatusText,
    [byte[]]$Body,
    [string]$ContentType
  )

  $header = "HTTP/1.1 $StatusCode $StatusText`r`n" +
            "Content-Type: $ContentType`r`n" +
            "Content-Length: $($Body.Length)`r`n" +
            "Cache-Control: no-store`r`n" +
            "Connection: close`r`n`r`n"
  $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
  $Stream.Write($headerBytes, 0, $headerBytes.Length)
  $Stream.Write($Body, 0, $Body.Length)
}

function Find-AvailablePort {
  param(
    [int]$StartPort,
    [int]$MaxAttempts = 40
  )

  for ($offset = 0; $offset -lt $MaxAttempts; $offset++) {
    $candidate = $StartPort + $offset
    $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $candidate)
    try {
      $probe.Start()
      return $candidate
    } catch {
      # occupied port, try next
    } finally {
      try { $probe.Stop() } catch { }
    }
  }

  throw "Could not find an available port in range $StartPort-$($StartPort + $MaxAttempts - 1)."
}

$rootFull = [System.IO.Path]::GetFullPath($Root)
$actualPort = Find-AvailablePort -StartPort $Port
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $actualPort)

try {
  $listener.Start()
  $url = "http://localhost:$actualPort/"
  Write-Host "SSW dashboard running at $url" -ForegroundColor Green
  if ($actualPort -ne $Port) {
    Write-Host "Port $Port was busy; switched to $actualPort." -ForegroundColor Yellow
  }
  Write-Host "Root: $rootFull"
  Write-Host "Press Ctrl+C to stop."
  Start-Process $url | Out-Null

  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
      $requestLine = $reader.ReadLine()
      if ([string]::IsNullOrWhiteSpace($requestLine)) {
        continue
      }

      while (($line = $reader.ReadLine()) -ne $null -and $line -ne "") { }

      $parts = $requestLine.Split(" ")
      if ($parts.Length -lt 2) {
        $body = [System.Text.Encoding]::UTF8.GetBytes("Bad request")
        Send-Response -Stream $stream -StatusCode 400 -StatusText "Bad Request" -Body $body -ContentType "text/plain; charset=utf-8"
        continue
      }

      $requestPath = [System.Uri]::UnescapeDataString($parts[1].TrimStart("/"))
      if ([string]::IsNullOrWhiteSpace($requestPath)) {
        $requestPath = "index.html"
      }

      $candidatePath = Join-Path $rootFull $requestPath
      $resolvedPath = [System.IO.Path]::GetFullPath($candidatePath)
      $pathAllowed = $resolvedPath.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)

      if (-not $pathAllowed -or -not (Test-Path -LiteralPath $resolvedPath -PathType Leaf)) {
        $body = [System.Text.Encoding]::UTF8.GetBytes("Not found")
        Send-Response -Stream $stream -StatusCode 404 -StatusText "Not Found" -Body $body -ContentType "text/plain; charset=utf-8"
        continue
      }

      $bytes = [System.IO.File]::ReadAllBytes($resolvedPath)
      $contentType = Get-ContentType -Path $resolvedPath
      Send-Response -Stream $stream -StatusCode 200 -StatusText "OK" -Body $bytes -ContentType $contentType
    } finally {
      $client.Close()
    }
  }
} finally {
  $listener.Stop()
}
