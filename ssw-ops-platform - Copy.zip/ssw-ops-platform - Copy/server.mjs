import { createReadStream, existsSync, statSync } from "node:fs";
import { extname, join, normalize } from "node:path";
import http from "node:http";

const root = normalize(process.cwd());
const port = Number(process.env.PORT || 4173);

const mimeTypes = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp"
};

function resolvePath(urlPath) {
  const cleaned = urlPath === "/" ? "/index.html" : urlPath;
  const decoded = decodeURIComponent(cleaned.split("?")[0]);
  return normalize(join(root, decoded));
}

http
  .createServer((request, response) => {
    const filePath = resolvePath(request.url || "/");

    if (!filePath.startsWith(root) || !existsSync(filePath)) {
      response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      response.end("Not found");
      return;
    }

    if (statSync(filePath).isDirectory()) {
      response.writeHead(302, { Location: `${request.url}/index.html` });
      response.end();
      return;
    }

    const ext = extname(filePath).toLowerCase();
    response.writeHead(200, {
      "Content-Type": mimeTypes[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    createReadStream(filePath).pipe(response);
  })
  .listen(port, () => {
    console.log(`SSW platform available at http://localhost:${port}`);
  });
